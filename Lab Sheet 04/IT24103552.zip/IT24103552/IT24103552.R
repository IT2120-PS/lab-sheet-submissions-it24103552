setwd("C:\\Users\\it24103552\\Desktop\\IT24103552")
getwd()

# 1
branch_data <- read.csv("Exercise.txt", header = TRUE, sep = ",")

# 2
head(branch_data)
str(branch_data)

# 3
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales",
        ylab = "Sales")

# 4
summary(branch_data$Advertising_X2)

# Interquartile range (IQR)
IQR(branch_data$Advertising_X2)


# 5
find_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("Upper Bound =",ub))
  print(paste("Lower Bound =",lb))
  
  outliers <- sort(z[z < lb | z > ub])
  
  if (length(outliers) > 0) {
    print(paste("Outliers :",paste(outliers,collapse = ",")))
  } else {
    print("No outliers detected.")
  }

# Check outliers in Years variable
find_outliers(branch_data$Years_X3)