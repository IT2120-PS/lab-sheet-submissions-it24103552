# set working directory
setwd("C:\\Users\\TUF\\Desktop\\IT24103552")
getwd()

data <- read.csv("Data.csv", header = TRUE)
print(data)

# i. Hypotheses
cat("Null Hypothesis (H₀): p_A = p_B = p_C = p_D = 0.25\n")
cat("Alternative Hypothesis (H₁): At least one p_i ≠ 0.25\n\n")

# ii. Chi-squared Test
# Observed data
observed <- c(120, 95, 85, 100)
snack_types <- c("A", "B", "C", "D")
total_obs <- sum(observed)

# Expected frequencies (equal probability)
expected <- rep(total_obs/4, 4)

# Manual calculation
chi_squared <- sum((observed - expected)^2 / expected)
df <- length(observed) - 1
p_value <- 1 - pchisq(chi_squared, df)

# Built-in test
test_result <- chisq.test(x = observed, p = c(0.25, 0.25, 0.25, 0.25))
print(test_result)

# Detailed table
results_table <- data.frame(
  Snack_Type = snack_types,
  Observed = observed,
  Expected = round(expected, 1),
  Contribution_to_Chi2 = round((observed - expected)^2 / expected, 3)
)
print(results_table)

# iii. Conclusion)
# If p-value < 0.05 → Reject H0 → Customers have different preferences
# If p-value >= 0.05 → Fail to reject H0 → All snacks equally likely
