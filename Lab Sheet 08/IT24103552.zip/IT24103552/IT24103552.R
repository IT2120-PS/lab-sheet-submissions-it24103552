setwd("C:\\Users\\TUF\\Desktop\\IT24103552")
getwd()

# Import data
data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
attach(data)

## 1.
pop_mean <- mean(data$Weight)
pop_sd <- sd(data$Weight)
pop_var <- var(data$Weight)

# Display results
pop_mean
pop_sd
pop_var

## 2.
samples <- matrix(nrow = 6, ncol = 25)
sample_means <- numeric(25)
sample_sds <- numeric(25)

# Generate 25 samples of size 6 with replacement
for(i in 1:25) {
  s <- sample(data$Weight, 6, replace = TRUE)
  samples[, i] <- s
  sample_means[i] <- mean(s)
  sample_sds[i] <- sd(s)
}

# Create results table
results <- data.frame(
  Sample = 1:25,
  Mean = round(sample_means, 4),
  SD = round(sample_sds, 4)
)

# Display first few rows
head(results)

## 3.
# Calculate mean and SD of sample means
mean_of_means <- mean(sample_means)
sd_of_means <- sd(sample_means)

# Display results
mean_of_means
sd_of_means

# Compare with theoretical values
theoretical_sd_of_means <- pop_sd / sqrt(6)
theoretical_sd_of_means
