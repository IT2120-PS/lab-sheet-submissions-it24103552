setwd("C:\\Users\\TUF\\Desktop\\IT24103552")
getwd()

# Question 1

# i)
# Answer: X follows a Binomial distribution with n = 50 and p = 0.85
# ii)
cat("Distribution: Binomial(n = 50, p = 0.85)\n")
pbinom(47,50,0.85,lower.tail = FALSE)

# Question 2

# i)
# Answer: X = Number of customer calls received in one hour
# ii)
# Answer: X follows a Poisson distribution with λ = 12
# iii)
dpois(15,12)